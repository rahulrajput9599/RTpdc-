#include <winsock2.h>
#include <iomanip>
// #include <bits/stdc++.h>
#include <chrono>
#include "cmdframe.h"
#include "socketinit.h"
#include "structures.h"
#include "utilities.h"
#include <iostream>
#include <cstdio>
#include <string>
#include <fstream>
#include <vector>
#include <map>
#pragma comment(lib, "ws2_32.lib")
#include<mutex>

SOCKET connection(std::string ipAddress, int PORT)
{
    const char *cString = ipAddress.c_str();
    SOCKET clientSocket = socketInit(cString, PORT);
    // closesocket(clientSocket);
    // WSACleanup();
    return clientSocket;
}
void startDataStream(SOCKET clientSocket, int pmuId,bool &isClose,std::vector<data_frame> & dfBuffer,std::map<int,cfg2_frame>& cfgMap,std::mutex &mtx)
{   
    bool ifCFGAsked =0;
    sendCFGCmdFrame(clientSocket, pmuId);
    cfg2_frame cfg = makeCFG2(clientSocket, pmuId);

    mtx.lock();
    cfgMap[pmuId] = cfg;
    mtx.unlock();

    sendDFCmdFrame(clientSocket, pmuId);
    std::string fileName = writeDataFrameFileHeader(cfg,pmuId);
   
    while (!closeOrNot(isClose,mtx))
    {
        data_frame df = makeDF(clientSocket, cfg, fileName, ifCFGAsked, pmuId);
        mtx.lock();
        dfBuffer.push_back(df);
        mtx.unlock();
        
    }
}
void closeDataStream(std::vector<std::pair<SOCKET,int>> & sockets, bool & isClose){
    int check;
    std::cin>>check;
    if(check==1){
        isClose = 1;
        for(int i=0;i<sockets.size();i++){
            sendCloseStreamCmdFrame(sockets[i].first,sockets[i].second);
            closesocket(sockets[i].first);
            WSACleanup();
        }
    }
}

