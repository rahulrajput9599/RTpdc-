Compile command 
```
g++ main.cpp ./modules/connection.cpp ./modules/cmdframe.cpp ./modules/socketinit.cpp ./modules/utilities.cpp ./modules/structures.cpp -o main.exe -lws2_32
```

Run
```
.\main.exe
```

### Close
### type 1 in the terminal and enter.
# TODO

- [ ] option for MySql database or csv
- [ ] write to MySql function
- [ ] make the sql database.

- [x] Thread pool.
- [x] Thread synchronisation.
- [x] dynamic wait time and timebase.
- [x] align the dataframes from multiple PMUs.

## 20-02-24 {2021eeb1156}
- [x] drop late packages.
- [x] write dynamic wait times function.
## 19-02-24 {2021eeb1156,2021eeb1157,2021eeb1199,2021eeb1197}
- [x] align the dataframes from multiple PMUs.
## 12-02-24 {2021eeb1156,2021eeb1157,2021eeb1199,2021eeb1197}
- [x] accept data from multiple pmu.
- [x] close socket logic implemented.
## 08-02-24 {2021eeb1156,2021eeb1157,2021eeb1199,2021eeb1197}
- [x] write into a live txt.
- [x] vary the data stream according to the stat word. what if stat changes more than once in the minute.
## 05-02-24 {2021eeb1156,2021eeb1157,2021eeb1199,2021eeb1197}
- [x] write in csv.
- [x] write code for 16bit data.
- [x] dynamic file naming.
## 03-02-24 {2021eeb1156}
- [x] make connection.cpp modular.  
- [x] structure the data printing.  
- [x] structure all the files.

