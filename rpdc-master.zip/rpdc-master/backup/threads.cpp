// C++ program to demonstrate
// multithreading using three
// different callables.
#include <iostream>
#include <thread>
using namespace std;
bool flag = true;
// A dummy function
void foo()
{
	while(flag){
        std::cout<<"hello from thread 1"<<endl;
    }
}

void takeInput(){
    while(flag){
        int x;
        std::cin>>x;
		std::cout<<std::endl;
        if(x==1)flag = 1;
        else flag = 0;
    }
}

// Driver code
int main()
{
	cout << "Threads 1 and 2 and 3 "
			"operating independently"
		<< endl;

	// This thread is launched by using
	// function pointer as callable
	thread th1(foo);

	// This thread is launched by using
	// function object as callable
	thread th2(takeInput);

	th1.join();
	th2.join();
	return 0;
}
