#include "./modules/structures.h"
#include "./modules/connection.h"
#include "./modules/socketinit.h"
#include "./modules/utilities.h"
#include <winsock2.h>
#include <iostream>
#include <chrono>
#include <thread>
#include <vector>
#include <map>
#include <utility>
#include <string>
#include <queue>
#include <algorithm>
#include <cmath>
#include <mutex>

std::mutex mtx;
std::vector<std::pair<SOCKET, int>> sockets;
std::map<int, cfg2_frame> cfgMap;
void connectPMU(std::string ip, int port, int pmuId, bool &isClose, std::vector<data_frame> &dfBuffer, std::mutex &mtx)
{
    SOCKET clientSocket;
    clientSocket = connection(ip, port);
    mtx.lock();
    sockets.push_back({clientSocket, pmuId});
    mtx.unlock();
    if (clientSocket != 1)
    {
        startDataStream(clientSocket, pmuId, isClose, dfBuffer, cfgMap, mtx);
    }
}

static bool customSort(data_frame df1, data_frame df2)
{
    // double time1 = (df1.soc) + (df1.fracsec / 1000000.0);
    // double time2 = (df2.soc) + (df2.fracsec / 1000000.0);
    // cfgMap[df1.idcode].timeBase
    // return time1 < time2;
    // std::lock_guard<std::mutex> lock(mtx);    
    // mtx.lock();
    double time1 = (df1.soc) + (df1.fracsec / ((double)(cfgMap[df1.idcode]).timeBase));
    double time2 = (df2.soc) + (df2.fracsec / ((double)(cfgMap[df2.idcode]).timeBase));
    // mtx.unlock();
    // std::cout<<cfgMap[df1.idcode].timeBase<<"  and  " << cfgMap[df2.idcode].timeBase<<std::endl;
    // std::cout<<time1<<" "<<time2<<std::endl;
    return time1 < time2;

}

void sortQVector(std::queue<std::vector<data_frame>> &taskQueue, bool &isClose)
{
    std::vector<data_frame> curVector;
    std::string fileName = "sortedData.csv";
    double lastPush = 0;
    while (!closeOrNot(isClose, mtx))
    {
        mtx.lock();
        if (!taskQueue.empty())
        {
            curVector = taskQueue.front();

            sort(curVector.begin(), curVector.end(), customSort);
            // mtx.lock();
            // double timeBase = (double)cfgMap[curVector[0].idcode].timeBase;
            // std::cout<<timeBase<<std::endl;
            // mtx.unlock();
            double timeBase = 1000000.0;
            while ((curVector.size() > 0) && (curVector[0].fracsec / timeBase + curVector[0].soc) < lastPush)
            {
                curVector.erase(curVector.begin());
            }
            for (auto df : curVector)
            {
                writeDataframe2File(fileName, df);
            }
            if (curVector.size() > 0)
            {
                lastPush = curVector.back().fracsec / timeBase + curVector.back().soc;
            }
            // std::cout<<lastPush<<std::endl;
            taskQueue.pop();
        }
        mtx.unlock();
    }
}
void runTimer(std::queue<std::vector<data_frame>> &taskQueue, std::vector<data_frame> &dfBuffer, bool &isClose)
// {
//     while (isClose != 1)
//     {
//         auto start = std::chrono::steady_clock::now();
//         while (std::chrono::steady_clock::now() - start < std::chrono::milliseconds(110))
//         {
//             // Do nothing, just wait for  110ms to pass
//         }
//         taskQueue.push(dfBuffer);
//         dfBuffer.clear();
//         // std::cout << "110ms elapsed\n";
//     }
// }

{
    int lastPackageArrivalTime = 0;
    int firstPackageArrivalTime = 1000;
    mtx.lock();
    for (auto i : cfgMap)
    {
        // std::cout<<"in the run timer and can see i as " <<i.first<< "and " <<i.second.dataRate<<std::endl;
        int packageTime = 1000.0 / (i.second.dataRate);
        // std::cout<<packageTime<<std::endl;
        if (packageTime > lastPackageArrivalTime)
        {
            lastPackageArrivalTime = packageTime;
        }
        if (packageTime < firstPackageArrivalTime)
        {
            firstPackageArrivalTime = packageTime;
        }
    }
    mtx.unlock();
    // std::cout<<firstPackageArrivalTime<<" and " << lastPackageArrivalTime<<std::endl;
    int product = lastPackageArrivalTime / firstPackageArrivalTime + (lastPackageArrivalTime % firstPackageArrivalTime != 0);
    int waitTime = (product * firstPackageArrivalTime - lastPackageArrivalTime) / 2;
    if (lastPackageArrivalTime == firstPackageArrivalTime)
        waitTime = 10;
    std::cout << std::endl
              << "wait time is -> " << waitTime << std::endl;

    while (!closeOrNot(isClose, mtx))
    {
        auto start = std::chrono::steady_clock::now();
        bool firstTime = true;
        if (firstTime)
        {

            while (std::chrono::steady_clock::now() - start < std::chrono::milliseconds(lastPackageArrivalTime + waitTime))
            {
            }
            mtx.lock();
            taskQueue.push(dfBuffer);
            dfBuffer.clear();
            mtx.unlock();
            firstTime = false;
        }
        else
        {
            while (std::chrono::steady_clock::now() - start < std::chrono::milliseconds(lastPackageArrivalTime))
            {
            }
            mtx.lock();
            taskQueue.push(dfBuffer);
            dfBuffer.clear();
            mtx.unlock();
        }

        // std::cout << "110ms elapsed\n";
    }
}

int main()
{
    bool isClose = 0;
    std::vector<data_frame> dfBuffer;
    std::queue<std::vector<data_frame>> taskQueue;

    int numThreads=1;

    std::vector<std::thread> threads;

    // Create the specified number of threads, passing the arguments to connectPMU
    PMU pmu1("172.26.36.98",4727,2);
    // PMU pmu2("172.26.37.162",4727,2);
    threads.emplace_back(connectPMU, pmu1.pmuIp, pmu1.port, pmu1.pmuId, std::ref(isClose), std::ref(dfBuffer),std::ref(mtx));
    // threads.emplace_back(connectPMU, pmu2.pmuIp, pmu2.port, pmu2.pmuId, std::ref(isClose), std::ref(dfBuffer),std::ref(mtx));
    

    // for(int i=0;i<numThreads;i++)
    // {
        // std::string ip="";
        // int port,id;
        // std::cin>>ip>>port>>ip;
        // PMU pmu(ip,port,id);
        // threads.emplace_back(connectPMU, pmu.pmuIp, pmu.port, pmu.pmuId, std::ref(isClose), std::ref(dfBuffer),std::ref(mtx));
    // }
    bool cfgMade = false;
    while (!cfgMade)
    {
        mtx.lock();
        if (cfgMap.size() > 1)
            cfgMade = true;
        mtx.unlock();
    }
    // std::cout<<cfgMap.size()<<std::endl;

    std::thread timerThread(runTimer, std::ref(taskQueue), std::ref(dfBuffer), std::ref(isClose));
    std::thread sortingThread(sortQVector, std::ref(taskQueue), std::ref(isClose));
    closeDataStream(sockets, isClose);
    for (auto& thread : threads) {
        thread.join();
    }
    // connectionThread1.join();
    // connectionThread2.join();
    timerThread.join();
    sortingThread.join();

    return 0;
}

