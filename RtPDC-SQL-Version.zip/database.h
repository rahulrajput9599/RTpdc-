#pragma once
#include "./modules/structures.h"
#include <unordered_map>
#include <algorithm>
#include <cctype>
#include <mysql.h>
#include <iostream>
#include<set>
#include <string>
#include <sstream>
MYSQL* DbSetup(const char* DbAddress, const char* UserName, const char* Password, int port);
std::string tableSetup(MYSQL* dbConnection, std::set<std::string> phasorHeadings, std::set<std::string> analogHeadings);
std::string tableNameFunc();
void writeDataframe2Db(MYSQL* dbConnection, data_frame dataFrame, std::string tableName, std::unordered_map<int, cfg2_frame>& cfgMap);
