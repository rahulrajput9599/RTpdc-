#include <winsock2.h>
#ifndef SOCKETINIT_H   
#define SOCKETINIT_H
SOCKET socketInit(const char* iPAddress, u_short portNum);
#endif