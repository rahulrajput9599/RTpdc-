

#include"cmdframe.h"
#include <chrono>
#include <iostream>
#include<winsock2.h>

using namespace std;
unsigned char DATASYNC[2],CFGSYNC[2],CMDSYNC[2],CMDDATASEND[2],CMDDATAOFF[2],CMDCFGSEND[2];
void cmdFrameInit(){
	// CMDSYNC = new unsigned char[2];
    CMDSYNC[0] = 0xaa;
	CMDSYNC[1] = 0x41;
	// CMDSYNC[2] = '\0';


	// CMDCFGSEND = new unsigned char[2];
	CMDCFGSEND[0] = 0x00;
	CMDCFGSEND[1] = 0x05;
	// CMDCFGSEND[2] = '\0'; 


	// CMDDATASEND = new unsigned char[2];
	CMDDATASEND[0] = 0x00;
	CMDDATASEND[1] = 0x02;
	// CMDDATASEND[2] = '\0'; 


	// CMDDATAOFF = new unsigned char[2];
	CMDDATAOFF[0] = 0x00;
	CMDDATAOFF[1] = 0x01;
	// CMDDATAOFF[2] = '\0'; 


	// DATASYNC = new unsigned char[2];
	DATASYNC[0] = 0xaa;
	DATASYNC[1] = 0x01;
	// DATASYNC[2] = '\0';
	

	// CFGSYNC = new unsigned char[2];
	CFGSYNC[0] = 0xaa;
	CFGSYNC[1] = 0x31;
	// CFGSYNC[2] = '\0'
}

uint16_t compute_CRC(unsigned char *message,int length)
{
    uint16_t crc=0x0ffff,temp,quick;
    int i;
    for(i=0;i<length;i++)
    {
        // Calculate the temporary value for the CRC
        temp=(crc>>8)^message[i];
        // Shift the CRC left by 8 bits
        crc<<=8;
        // Calculate the quick value for the CRC
        quick=temp ^ ( temp >>4);
        // XOR the quick value with the CRC
        crc ^=quick;
        // Shift the quick value left by 5 bits
        quick<<=5;
        // XOR the quick value with the CRC
        crc ^=quick;
        // Shift the quick value left by 7 bits
        quick <<=7;
        // XOR the quick value with the CRC
        crc ^= quick;
    }
    return crc;
}



void int_to_ascii_convertor(unsigned int n,unsigned char hex[]) 
{	// converts integer to ascii
	hex[0] = n >> 8;
	hex[1] = n ;
	// cout<<hex[0]<< " " <<hex[1]<<endl;
}

void long_int_to_ascii_convertor(unsigned long int n,unsigned char hex[]) 
{
	// converts long integer to ascii
	hex[0] = n >> 24;
	hex[1] = n >> 16;
	hex[2] = n >> 8;
	hex[3] = n ;
}

void byte_by_byte_copy(unsigned char dst[],unsigned char src[],int index,int n) 
{
	// copies n bytes from src to dst starting from index
	int i;
	for(i = 0;i<n; i++) 
		dst[index + i] = src[i];					
}
void create_command_frame(int type,int pmu_id,char cmdframe[]) 
{
    // creates command frame based on type of request
    int f = 18;
    //define the variables to store the current time in seconds and fractions of a second
    long int sec,frac = 0;
    //initialize the command frame
    cmdFrameInit();
    //define the variables to store the frame size, PMU ID, SOC, and fractional second
    unsigned char fsize[2],pmuid[2],soc[4],fracsec[4];
    //define the variable to store the checksum
    uint16_t chk;
    //memset(cmdframe,'\0',18);

    //convert the frame size, PMU ID, SOC, and fractional second to ASCII
    int_to_ascii_convertor(f,fsize);
    int_to_ascii_convertor(pmu_id,pmuid);

    //get the current time in seconds
    sec= (long int)time (NULL);

    //convert the current time in seconds to ASCII
    long_int_to_ascii_convertor(sec,soc);
	//convert the fractional second to ASCII
    long_int_to_ascii_convertor(frac,fracsec);

    //create and send the command frame based on the type of request
    switch(type) {

    case 1 : // SEND CFG
        byte_by_byte_copy((unsigned char *)cmdframe,CMDSYNC,0,2);
        byte_by_byte_copy((unsigned char *)cmdframe,fsize,2,2);
        byte_by_byte_copy((unsigned char *)cmdframe,pmuid,4,2);
        byte_by_byte_copy((unsigned char *)cmdframe,soc,6,4);
        byte_by_byte_copy((unsigned char *)cmdframe,fracsec,10,4);
        byte_by_byte_copy((unsigned char *)cmdframe,CMDCFGSEND,14,2);
        chk = compute_CRC((unsigned char *)cmdframe,16);
        cmdframe[16]=(chk >> 8) & ~(~0<<8);   /* CHKSUM high byte; */
        cmdframe[17] = (chk ) & ~(~0<<8);      /* CHKSUM low byte;  */
        break;

    case 2 : // SEND DATA
        byte_by_byte_copy((unsigned char *)cmdframe,CMDSYNC,0,2);
        byte_by_byte_copy((unsigned char *)cmdframe,fsize,2,2);
        byte_by_byte_copy((unsigned char *)cmdframe,pmuid,4,2);
        byte_by_byte_copy((unsigned char *)cmdframe,soc,6,4);
        byte_by_byte_copy((unsigned char *)cmdframe,fracsec,10,4);
        byte_by_byte_copy((unsigned char *)cmdframe,CMDDATASEND,14,2);
        chk = compute_CRC((unsigned char *)cmdframe,16);
        cmdframe[16]=(chk >> 8) & ~(~0<<8);   /* CHKSUM high byte; */
        cmdframe[17] = (chk ) & ~(~0<<8);      /* CHKSUM low byte;  */
        break;

    case 3 : // TURN OFF DATA
        byte_by_byte_copy((unsigned char *)cmdframe,CMDSYNC,0,2);
        byte_by_byte_copy((unsigned char *)cmdframe,fsize,2,2);
        byte_by_byte_copy((unsigned char *)cmdframe,pmuid,4,2);
        byte_by_byte_copy((unsigned char *)cmdframe,soc,6,4);
        byte_by_byte_copy((unsigned char *)cmdframe,fracsec,10,4);
        byte_by_byte_copy((unsigned char *)cmdframe,CMDDATAOFF,14,2);
        chk = compute_CRC((unsigned char *)cmdframe,16);
        cmdframe[16]=(chk >> 8) & ~(~0<<8);   /* CHKSUM high byte; */
        cmdframe[17] = (chk ) & ~(~0<<8);      /* CHKSUM low byte;  */
        break;
    default: std::cout<<"Please enter a valid request?\n";
        break;
    }
}

void sendCFGCmdFrame(SOCKET clientSocket, int pmuId)
{
    // Create an array of 18 unsigned characters to hold the command frame
    unsigned char cmdframe[18];
    
    // Fill the command frame with the appropriate information for a CFG command
    create_command_frame(1, pmuId, (char *)cmdframe); // 1 = send CFG, 2 = data on, 3 = data off

    // Attempt to send the command frame to the client socket
    if (send(clientSocket, (char *)cmdframe, sizeof(cmdframe), 0) == SOCKET_ERROR)
    {
        // If sending fails, print an error message with the Windows Sockets error code
        printf("send failed: %d\n", WSAGetLastError());
        
        // Close the client socket
        closesocket(clientSocket);
        
        // Clean up Windows Sockets
        WSACleanup();
        
        // Exit the function
        return;
    }
}

void sendDFCmdFrame(SOCKET clientSocket, int pmuId) {
    // Create a buffer of size 18 bytes to hold the command frame
    unsigned char cmdframe[18];

    // Populate the command frame with relevant data
    create_command_frame(2, pmuId, (char *)cmdframe);

    // Send the command frame to the client socket
    if (send(clientSocket, (char *)cmdframe, sizeof(cmdframe), 0) == SOCKET_ERROR) {
        // Handle error sending the frame
        printf("send failed: %d\n", WSAGetLastError());
        // Close the client socket
        closesocket(clientSocket);
        // Clean up Winsock library resources
        WSACleanup();
        return;
    }
}
void sendCloseStreamCmdFrame(SOCKET clientSocket, int pmuId) {
    // Create a buffer for the command frame
    unsigned char cmdframe[18];

    // Populate the command frame with relevant data
    create_command_frame(3, pmuId, (char *)cmdframe); // 1 = send CFG, 2 = data on , 3 = data off

    // Attempt to send the command frame to the client socket
    if (send(clientSocket, (char *)cmdframe, sizeof(cmdframe), 0) == SOCKET_ERROR)
    {
        // Handle error sending the frame
        printf("send failed: %d\n", WSAGetLastError());
        // Close the client socket
        closesocket(clientSocket);
        // Clean up Winsock library resources
        WSACleanup();
        return;
    }
}
