
/*
#ifndef structures_h
#define structures_h
#include <vector>
#include <string>

class PMU
{
public:
    std::string pmuIp;
    int pmuId;
    int port;

    PMU(const std::string &ip, int pt, int id)
    {
        pmuIp = ip;
        pmuId = id;
        port = pt;
    }
};
class dbCred {
public:
    std::string serverAddress;
    std::string userName;
    std::string password;
    int port;
    dbCred(std::string serverAddress_input, std::string userName_input, std::string password_input, int port_input) {
        serverAddress = serverAddress_input;
        userName = userName_input;
        password = password_input;
        port = port_input;
    }
};

class cfg2_frame
{
public:
    int framesize;
    int idcode;
    long int soc;
    long int fracsec;
    long int timeBase;
    int numPmu;
    std::string stn;
    std::string format;
    int phnmr;
    int annmr;
    int dgnmr;
    std::vector<std::string> chnam;
    std::vector<std::pair<std::string, long double>> phunit;
    std::vector<std::pair<std::string, long double>> anunit;
    // vector<vector<string>> digunit; // Two 16-bit words are provided for each digital word.
    int fnom;
    int dataRate;
};
class data_frame
{
public:
    int framesize;
    int idcode;
    long int soc;
    long int fracsec;
    std::string stat;
    std::vector<std::pair<double, double>> phasors;
    double freq;
    double dfreq;
    std::vector<double> analogs;
    std::vector<int> digital;
};
#endif
*/

#ifndef structures_h
#define structures_h
#include <vector>
#include <string>

// Class representing a Phasor Measurement Unit (PMU) with IP address, ID, and port number.
class PMU
{
public:
    // IP address of the PMU.
    std::string pmuIp;
    // Unique identifier for the PMU.
    int pmuId;
    // Port number for communication with the PMU.
    int port;

    // Constructor to initialize PMU with IP, port, and ID.
    PMU(const std::string &ip, int pt, int id)
    {
        pmuIp = ip; // Assign IP address
        pmuId = id; // Assign PMU ID
        port = pt;  // Assign port number
    }
};

// Class representing database credentials including server address, username, password, and port.
class dbCred
{
public:
    // Server address for database connection.
    std::string serverAddress;
    // Username for database authentication.
    std::string userName;
    // Password for database authentication.
    std::string password;
    // Port number for database connection.
    int port;

    // Constructor to initialize database credentials.
    dbCred(std::string serverAddress_input, std::string userName_input, std::string password_input, int port_input)
    {
        serverAddress = serverAddress_input; // Assign server address
        userName = userName_input;           // Assign username
        password = password_input;           // Assign password
        port = port_input;                   // Assign port number
    }
};

// Class representing a configuration frame with various parameters like frame size, ID code, SOC, etc.
class cfg2_frame
{
public:
    // Frame size.
    int framesize;
    // ID code.
    int idcode;
    // second of century (SOC).
    long int soc;
    // Fraction of seconds.
    long int fracsec;
    // Time base.
    long int timeBase;
    // Number of PMUs.
    int numPmu;
    // Station name.
    std::string stn;
    // Format of the frame.
    std::string format;
    // no of Phasors.
    int phnmr;
    // no of Analogs.
    int annmr;
    // no of Digitals.
    int dgnmr;
    // Channel names.
    std::vector<std::string> chnam;
    // Phase unit.
    std::vector<std::pair<std::string, long double>> phunit;
    // Analog unit.
    std::vector<std::pair<std::string, long double>> anunit;

     int fnom;
    // Data rate.
    int dataRate;
};

// Class representing a data frame with various parameters like frame size, ID code, SOC, etc., and specific to data processing.
class data_frame
{
public:
    // Frame size.
    int framesize;
    // ID code.
    int idcode;
    // second of century (SOC).
    long int soc;
    // Fraction of second.
    long int fracsec;
    // Status string.
    std::string stat;
    // Phasors represented as pairs of doubles (magnitudes and angles).
    std::vector<std::pair<double, double>> phasors;
    // Frequency.
    double freq;
    // Delta frequency.
    double dfreq;
    // Analog values.
    std::vector<double> analogs;
    // Digital values.
    std::vector<int> digital;
};
#endif
