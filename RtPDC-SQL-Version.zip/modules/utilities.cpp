// #include <bits/stdc++.h>
#include "structures.h"
#include "cmdframe.h"
#include <fstream>
#include "utilities.h"
#include <winsock2.h>
#include <ctime>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <math.h>
#include <iomanip>
#include <sstream>
#include <unordered_map>
#include <cassert>
#include <mutex>
#include <mysql.h>
// #undef max
constexpr double MAX_DOUBLE = 0x1.fffffffffffffp+1023;

bool closeOrNot(bool &isClose,std::mutex &mtx){
        mtx.lock();
        bool close = isClose;
        mtx.unlock();
        return close;
}

// Function to remove all occurrences of a specified substring from a given string.
std::string removeSubstring(std::string str) {
    // Copy the input string to a new string to avoid modifying the original.
    std::string result = str;
    // The substring to be removed.
    std::string substr = "ffffff";
    // Find the first occurrence of the substring in the result string.
    size_t pos = result.find(substr);
    // Loop until no more occurrences of the substring are found.
    while (pos != std::string::npos) {
        // Erase the found substring from the result string.
        result.erase(pos, substr.size());
        // Find the next occurrence of the substring in the result string.
        pos = result.find(substr);
    }
    // Return the modified string with all occurrences of the substring removed.
    return result;
}


// Function to convert a portion of a character array to a hexadecimal string.
std::string returnHex(char buffer[], int start, int end)
{
    std::stringstream ss;
    ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(buffer[start]);
    for (int i = start + 1; i <= end; i++)
    {
        ss << std::setw(2) << static_cast<int>(buffer[i]);
    }
    return ss.str();
}




// Function to convert a portion of a character array to a hexadecimal string and remove a specified substring.
std::string hexValue(char buffer[], int start, int end) {
    // Convert the specified portion of the character array to a hexadecimal string.
    std::string hexString = returnHex(buffer, start, end);
    // Remove all occurrences of the substring "ffffff" from the hexadecimal string.
    return removeSubstring(hexString);
}
// Function to remove all spaces from a given string
std::string removeSpaces(std::string str)
{
    // Create a copy of the input string to avoid modifying the original
    std::string noSpaces = str;
    
    // Use the remove function to shift all non-space characters to the front
    // and then erase the remaining spaces from the end of the string
    noSpaces.erase(remove(noSpaces.begin(), noSpaces.end(), ' '), noSpaces.end());
    
    // Return the modified string without spaces
    return noSpaces;
}




/*
Function that converts a binary string to its decimal equivalent
*/
int binaryToDecimal(std::string binaryString)
{
    // Initialize the decimal value to 0
    int decimalValue = 0;
    
    // Start with a base of 1 for the least significant bit
    int base = 1;
    
    // Get the length of the binary string
    int length = binaryString.length();

    // Iterate through the binary string from the end to the beginning
    for (int i = length - 1; i >= 0; i--)
    {
        // If the current character is '1', add the current base value to the decimal value
        if (binaryString[i] == '1')
        {
            decimalValue += base;
        }
        
        // Double the base for the next bit
        base = base * 2;
    }
    
    // Return the decimal value
    return decimalValue;
}



// Function to remove trailing zeros from a given string
std::string removeTrailingZeros(std::string str)
{
    // Get the length of the input string
    int len = str.length();
    
    // Loop until the string is empty or the last two characters are not both '0'
    while (len > 0 && str[len - 1] == '0' && len > 1 && str[len - 2] == '0')
    {
        // Remove the last two characters from the string
        str.pop_back();
        str.pop_back();
        
        // Decrease the length by 2 since two characters were removed
        len -= 2;
    }
    
    // Return the modified string without trailing zeros
    return str;
}



// Function to convert a hexadecimal string to ASCII
std::string hexToAscii(std::string hex)
{
    // Create a stringstream to build the ASCII string
    std::stringstream ss;
    
    // Iterate over the hex string two characters at a time
    for (size_t i = 0; i < hex.length(); i += 2)
    {
        // Convert each pair of hex digits to an unsigned char
        unsigned char byte = static_cast<unsigned char>(std::stoul(hex.substr(i, 2), nullptr, 16));
        
        // Check if the byte is not a null character
        if (byte != '\0')
        {
            // Append the byte to the stringstream as ASCII
            ss << byte;
        }
    }
    
    // Return the ASCII string
    return ss.str();
}



// Function to convert ASCII data to a hexadecimal string
std::string toHex(std::string data)
{
    // Define the hexadecimal characters
    char const hex_chars[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    
    // Initialize an empty string to hold the hexadecimal representation
    std::string str = "";
    
    // Iterate over each byte in the data
    for (int i = 0; i < data.length(); i++)
    {
        // Extract the current byte
        char const byte = data[i];
        
        // Convert the high nibble (4 bits) of the byte to a hex character
        str += hex_chars[(byte & 0xF0) >> 4];
        
        // Convert the low nibble (4 bits) of the byte to a hex character
        str += hex_chars[(byte & 0x0F) >> 0];
    }
    
    // Return the hexadecimal string
    return str;
}


// Function to convert a hexadecimal string to its decimal equivalent
int hexToDecimal(std::string str)
{
    // Use std::stoll to convert the hexadecimal string to a long long integer
    // The third argument specifies the base of the number, which is 16 for hexadecimal
    return std::stoll(str, nullptr, 16);
}

// Function to convert a hexadecimal string to its binary representation
std::string hexToBinary(std::string hex)
{
    // Create a map to convert hexadecimal digits to their binary representations
    std::unordered_map<char, std::string> hexToBinMap{
        {'0', "0000"}, {'1', "0001"}, {'2', "0010"}, {'3', "0011"}, {'4', "0100"}, {'5', "0101"}, {'6', "0110"}, {'7', "0111"}, {'8', "1000"}, {'9', "1001"}, {'A', "1010"}, {'B', "1011"}, {'C', "1100"}, {'D', "1101"}, {'E', "1110"}, {'F', "1111"}};

    // Initialize an empty string to hold the binary representation
    std::string binary;
    
    // Iterate over each character in the hexadecimal string
    for (char digit : hex)
    {
        // Convert the hexadecimal digit to uppercase to ensure consistency
        // and then append its binary representation to the binary string
        binary += hexToBinMap[toupper(digit)];
    }
    
    // Return the binary representation of the hexadecimal string
    return binary;
}


// Function to convert a binary string to a floating-point number, handling different formats based on a flag
double binToFloatMag(std::string binaryStr, int flag)
{
    // Check the flag to determine the format of the binary string
    if (flag == 3)
    {
        // Convert the binary string to an unsigned long integer
        unsigned long src = std::stoul(binaryStr, nullptr, 2);
        int s, e;
        long f;
        double value;

        // Extract the sign, exponent, and fraction from the binary string
        s = (src & 0x80000000UL) >> 31;
        e = (src & 0x7F800000UL) >> 23;
        f = (src & 0x007FFFFFUL);

        // Handle special cases for NaN, infinity, and zero
        if (e == 255 && f != 0)
        {
            /* NaN (Not a Number) */
            value = MAX_DOUBLE;
        }
        else if (e == 255 && f == 0 && s == 1)
        {
            /* Negative infinity */
            value = -MAX_DOUBLE;
        }
        else if (e == 255 && f == 0 && s == 0)
        {
            /* Positive infinity */
            value = MAX_DOUBLE;
        }
        else if (e > 0 && e < 255)
        {
            /* Normal number */
            f += 0x00800000UL;
            if (s)
                f = -f;
            value = std::ldexp(f, e - 150);
        }
        else if (e == 0 && f != 0)
        {
            /* Denormal number */
            if (s)
                f = -f;
            value = std::ldexp(f, -149);
        }
        else if (e == 0 && f == 0 && s == 1)
        {
            /* Negative zero */
            value = 0;
        }
        else if (e == 0 && f == 0 && s == 0)
        {
            /* Positive zero */
            value = 0;
        }
        else
        {
            /* Unhandled case */
            assert(false && "Unhandled case in decode_ieee_single()");
        }

        return value;
    }

    else if (flag == 1)
    {
        // Extract the sign, exponent, and fraction from the binary string
        int sign = binaryStr[0] - '0';
        int exponent = (binaryStr[1] - '0') * 8 + (binaryStr[2] - '0') * 4 + (binaryStr[3] - '0') * 2 + (binaryStr[4] - '0');
        int fraction = (binaryStr[5] - '0') * 512 + (binaryStr[6] - '0') * 256 + (binaryStr[7] - '0') * 128 + (binaryStr[8] - '0') * 64 +
                       (binaryStr[9] - '0') * 32 + (binaryStr[10] - '0') * 16 + (binaryStr[11] - '0') * 8 + (binaryStr[12] - '0') * 4 +
                       (binaryStr[13] - '0') * 2 + (binaryStr[14] - '0');

        // Handle special cases for NaN, infinity, and zero
        if (exponent == 31 && fraction != 0)
        {
            return std::nan(""); // NaN
        }
        else if (exponent == 31)
        {
            return sign ? -std::numeric_limits<float>::infinity() : std::numeric_limits<float>::infinity(); // Inf
        }
        else if (exponent == 0 && fraction == 0)
        {
            return sign ? -0.0f : 0.0f; // Zero
        }

        // Calculate the actual value
        float value = static_cast<float>(fraction) / pow(2, 10);
        value += pow(2, exponent - 15);
        return sign ? -value : value;
    }

    // Return 0.0 if the flag is not recognized
    return 0.0;
}



// Function to print the hexadecimal representation of an array of characters
void printHex(char *arr, int size)
{
    // Iterate over each element in the array
    for (int i = 0; i < size; i++)
    {
        // Print the hexadecimal representation of the current element
        // Cast to unsigned char to ensure correct formatting
        printf("%02x ", (unsigned char)arr[i]);
        
        // After every 16 elements, print a newline to format the output
        if ((i + 1) % 16 == 0)
        {
            printf("\n");
        }
    }
    
    // Print a final newline to separate the output from subsequent text
    printf("\n");
}



// Function to convert a binary string to a floating-point number representing an angle, handling different formats based on a flag
double binToFloatAngle(std::string binary, int flag)
{
    // Check the flag to determine the format of the binary string
    if (flag == 3)
    {
        // Convert the binary string to an unsigned long integer
        unsigned long src = std::stoul(binary, nullptr, 2);
        int s, e;
        long f;
        double value;

        // Extract the sign, exponent, and fraction from the binary string
        s = (src & 0x80000000UL) >> 31;
        e = (src & 0x7F800000UL) >> 23;
        f = (src & 0x007FFFFFUL);

        // Initialize a temporary variable to represent the maximum double value
        double temp = MAX_DOUBLE;

        // Handle special cases for NaN, infinity, and zero
        if (e == 255 && f != 0)
        {
            /* NaN (Not a Number) */
            value = temp;
        }
        else if (e == 255 && f == 0 && s == 1)
        {
            /* Negative infinity */
            value = -temp;
        }
        else if (e == 255 && f == 0 && s == 0)
        {
            /* Positive infinity */
            value = temp;
        }
        else if (e > 0 && e < 255)
        {
            /* Normal number */
            f += 0x00800000UL;
            if (s)
                f = -f;
            value = std::ldexp(f, e - 150);
        }
        else if (e == 0 && f != 0)
        {
            /* Denormal number */
            if (s)
                f = -f;
            value = std::ldexp(f, -149);
        }
        else if (e == 0 && f == 0 && s == 1)
        {
            /* Negative zero */
            value = 0;
        }
        else if (e == 0 && f == 0 && s == 0)
        {
            /* Positive zero */
            value = 0;
        }
        else
        {
            /* Unhandled case */
            assert(false && "Unhandled case in decode_ieee_single()");
        }

        // Convert the value to degrees and return it
        return value * 180.0 / 3.14;
    }

    else if (flag == 1)
    {
        // Extract the sign, exponent, and fraction from the binary string
        int sign = binary[0] - '0';
        int exponent = (binary[1] - '0') * 8 + (binary[2] - '0') * 4 + (binary[3] - '0') * 2 + (binary[4] - '0');
        int fraction = (binary[5] - '0') * 512 + (binary[6] - '0') * 256 + (binary[7] - '0') * 128 + (binary[8] - '0') * 64 +
                       (binary[9] - '0') * 32 + (binary[10] - '0') * 16 + (binary[11] - '0') * 8 + (binary[12] - '0') * 4 +
                       (binary[13] - '0') * 2 + (binary[14] - '0');

        // Handle special cases for NaN, infinity, and zero
        if (exponent == 31 && fraction != 0)
        {
            return std::nan(""); // NaN
        }
        else if (exponent == 31)
        {
            return sign ? -std::numeric_limits<float>::infinity() : std::numeric_limits<float>::infinity(); // Inf
        }
        else if (exponent == 0 && fraction == 0)
        {
            return sign ? -0.0f : 0.0f; // Zero
        }

        // Calculate the actual value
        float value = static_cast<float>(fraction) / pow(2, 10);
        value += pow(2, exponent - 15);

        // Convert the value to degrees and return it, considering the sign
        if (sign == 1)
        {
            return -value * 180.0 / 3.14;
        }
        else
        {
            return value * 180.0 / 3.14;
        }
    }

    // Return 0 if the flag is not recognized
    return 0;
}




// Function to write a cfg2_frame structure to a file
void writeCFG2File(std::string fileName, cfg2_frame *cfgFrame)
{
    // Create an output file stream object
    std::ofstream fout;
    
    // Define a string to be used as a separator line in the output file
    std::string hashLine = "#################################################################################################################################################################";
    
    // Open the file with the given file name
    fout.open(fileName);
    
    // Check if the file stream is open and ready for writing
    while (fout)
    {
        // Write the separator line to the file
        fout << hashLine << std::endl;
        
        // Write the FRAMESIZE field to the file
        fout << "FRAMESIZE" << " " << std::to_string(cfgFrame->framesize) << std::endl;
        
        // Write the IDCODE field to the file
        fout << "IDCODE" << " " << std::to_string(cfgFrame->idcode) << std::endl;
        
        // Write the SOC field to the file
        fout << "SOC" << " " << std::to_string(cfgFrame->soc) << std::endl;
        
        // Write the FRACSEC field to the file
        fout << "FRACSEC" << " " << std::to_string(cfgFrame->fracsec) << std::endl;
        
        // Write the TIME_BASE field to the file
        fout << "TIME_BASE" << " " << std::to_string(cfgFrame->timeBase) << std::endl;
        
        // Write the NUM_PMU field to the file
        fout << "NUM_PMU" << " " << std::to_string(cfgFrame->numPmu) << std::endl;
        
        // Write the STN field to the file
        fout << "STN" << " " << cfgFrame->stn << std::endl;
        
        // Write the FORMAT field to the file
        fout << "FORMAT" << " " << cfgFrame->format << std::endl;
        
        // Write the PHNMR field to the file
        fout << "PHNMR" << " " << cfgFrame->phnmr << std::endl;
        
        // Write the ANNMR field to the file
        fout << "ANNMR" << " " << cfgFrame->annmr << std::endl;
        
        // Write the DGNMR field to the file
        fout << "DGNM" << " " << cfgFrame->dgnmr << std::endl;
        
        // Write the CHNAM fields to the file
        for (int i = 0; i < cfgFrame->chnam.size(); i++)
        {
            fout << "CHNAM" << " " << cfgFrame->chnam[i] << std::endl;
        }
        
        // Write the PHUNIT fields to the file
        for (int i = 0; i < cfgFrame->phunit.size(); i++)
        {
            fout << "PHUNIT" << " " << cfgFrame->phunit[i].first << " " << cfgFrame->phunit[i].second << std::endl;
        }
        
        // Write the ANUNIT fields to the file
        for (int i = 0; i < cfgFrame->anunit.size(); i++)
        {
            fout << "ANUNIT" << " " << cfgFrame->anunit[i].first << " " << cfgFrame->anunit[i].second << std::endl;
        }
        
        // Write the FNOM field to the file
        fout << "FNOM" << " " << cfgFrame->fnom << std::endl;
        
        // Write the DATARATE field to the file
        fout << "DATARATE" << " " << cfgFrame->dataRate << std::endl;
        
        // Break out of the loop after writing all fields
        break;
    }
}




// Function to create a cfg2_frame object from received data over a socket
cfg2_frame makeCFG2(SOCKET clientSocket, int pmuId)
{
    // Initialize a cfg2_frame object
    cfg2_frame cfg;

    // Buffer to store received data
    char receive_data_buffer[2048];

    // Receive data from the client socket
    int data_bytes_read = recv(clientSocket, receive_data_buffer, sizeof(receive_data_buffer), 0);

    // Check if the data reception was successful
    if (data_bytes_read == -1)
    {
        // If not, get the error code and return the empty cfg2_frame object
        int err = WSAGetLastError();
        return cfg;
    }

    // Convert specific parts of the received data to hexadecimal and then to decimal
    std::string hex = hexValue(receive_data_buffer, 2, 3);
    cfg.framesize = hexToDecimal(hex);
    cfg.idcode = hexToDecimal(hexValue(receive_data_buffer, 4, 5));
    cfg.soc = hexToDecimal(hexValue(receive_data_buffer, 6, 9));
    cfg.fracsec = hexToDecimal(hexValue(receive_data_buffer, 10, 13));
    cfg.timeBase = hexToDecimal(hexValue(receive_data_buffer, 14, 17));
    cfg.numPmu = hexToDecimal(hexValue(receive_data_buffer, 18, 19));

    // Convert specific parts of the received data to ASCII
    cfg.stn = hexToAscii(hexValue(receive_data_buffer, 20, 35));

    // Convert specific parts of the received data to binary
    cfg.format = hexToBinary(hexValue(receive_data_buffer, 39, 39));

    // Convert specific parts of the received data to decimal
    cfg.phnmr = hexToDecimal(hexValue(receive_data_buffer, 40, 41));
    cfg.annmr = hexToDecimal(hexValue(receive_data_buffer, 42, 43));
    cfg.dgnmr = hexToDecimal(hexValue(receive_data_buffer, 44, 45));

    // Loop to extract channel names from the received data
    int curr = 46;
    for (int i = 46; i < (curr + (cfg.phnmr + cfg.annmr + cfg.dgnmr * 16) * 16); i += 16)
    {
        cfg.chnam.push_back(hexToAscii(hexValue(receive_data_buffer, i, i + 15)));
    };

    // Update the current position in the received data buffer
    curr = curr + ((cfg.phnmr + cfg.annmr + cfg.dgnmr * 16) * 16);

    // Loop to extract phase unit information from the received data
    int chIndex = 0;
    for (int i = curr; i < curr + cfg.phnmr * 4; i += 4)
    {
        cfg.phunit.push_back({cfg.chnam[chIndex], hexToDecimal(hexValue(receive_data_buffer, i + 1, i + 3))});
        chIndex++;
    }

    // Update the current position and channel index for the next loop
    chIndex = cfg.phnmr;
    curr += cfg.phnmr * 4;

    // Loop to extract analog unit information from the received data
    for (int i = curr; i < curr + cfg.annmr * 4; i += 4)
    {
        cfg.anunit.push_back({cfg.chnam[chIndex], hexToDecimal(hexValue(receive_data_buffer, i + 1, i + 3))});
        chIndex++;
    }

    // Update the current position in the received data buffer
    curr += cfg.annmr * 4 + cfg.dgnmr * 4;

    // Extract the fnomType from the received data
    std::string fnomType = hexValue(receive_data_buffer, curr, curr + 1);

    // Determine the fnom value based on the last character of fnomType
    if (fnomType.back() == '1')
        cfg.fnom = 50;
    else
        cfg.fnom = 60;

    // Extract the data rate from the received data
    cfg.dataRate = hexToDecimal(hexValue(receive_data_buffer, curr + 4, curr + 5));

    // Get the current date and time
    std::time_t now = std::time(nullptr);
    std::tm *local_now = std::localtime(&now);

    // Format the date and time string
    char buffer[16];
    std::strftime(buffer, sizeof(buffer), "_%Y%m%d_%H%M", local_now);
    std::string date_time_str(buffer);

    // Construct the file name using the pmuId and the current date and time
    std::string fileName = "./output_cfg/CFG_" + std::to_string(pmuId) + date_time_str + ".txt";

    // Write the cfg2_frame object to a file
    writeCFG2File(fileName, &cfg);

    // Return the cfg2_frame object
    return cfg;
}



// Function to write the header of a data frame file based on the cfg2_frame object and pmuId
std::string writeDataFrameFileHeader(cfg2_frame cfg, int pmuId)
{
    // Get the current date and time
    std::time_t now = std::time(nullptr);
    std::tm *local_now = std::localtime(&now);

    // Format the date and time string
    char buffer[16];
    std::strftime(buffer, sizeof(buffer), "_%Y%m%d_%H%M", local_now);
    std::string date_time_str(buffer);

    // Construct the file name using the pmuId and the current date and time
    std::string fileName = "./output_data/df_" + std::to_string(pmuId) + date_time_str + ".csv";

    // Open the file for appending data
    std::ofstream fout;
    std::string fileName1 = "sortedData.csv";
    fout.open(fileName1, std::ios::app);

    // Initialize the headings string
    std::string headings = "";

    // Add static headings to the file
    headings += "SOC,";
    headings += "FRACSEC,";
    headings += "PMU ID,";
    headings += "STAT,";
    headings += "FREQ,";

    // Loop to add phase measurement unit (PMU) headings
    int headerIdx = 0;
    for (; headerIdx < cfg.phnmr; headerIdx++)
    {
        headings += '[' + cfg.chnam[headerIdx] + "](Mag)" + ",";
        headings += '[' + cfg.chnam[headerIdx] + "](Angle)" + ",";
    }

    // Loop to add analog measurement unit (AMU) headings
    for (; headerIdx < cfg.annmr; headerIdx++)
    {
        headings += '[' + cfg.chnam[headerIdx] + "]" + ",";
    }

    // Add a newline character at the end of the headings
    headings += "\n";

    // Write the headings to the file
    fout << headings;

    // Close the file
    fout.close();

    // Return the constructed file name
    return fileName;
}



// Function to write a data frame to a file
void writeDataframe2File(std::string fileName, data_frame dataFrame)
{
    // Open the file for appending data
    std::ofstream fout;
    fout.open(fileName, std::ios::app);

    // Initialize the string to hold the data to be written
    std::string headingsData = "";

    // Convert and append the SOC value to the string
    headingsData += std::to_string((dataFrame.soc)) + ",";

    // Convert and append the FRACSEC value to the string
    headingsData += std::to_string((dataFrame.fracsec)) + ",";

    // Convert and append the IDCODE value to the string
    headingsData += std::to_string((dataFrame.idcode)) + ",";

    // Append the STAT value directly to the string (assuming it's already a string)
    headingsData += (dataFrame.stat) + ",";

    // Convert and append the FREQ value to the string
    headingsData += std::to_string((dataFrame.freq)) + ",";

    // Loop through the phasors vector and append each phasor's magnitude and angle to the string
    for (int i = 0; i < dataFrame.phasors.size(); i++)
    {
        headingsData += (std::to_string((dataFrame.phasors[i].first)) + "," + std::to_string((dataFrame.phasors[i].second)) + ",");
    }

    // Loop through the analogs vector and append each analog value to the string
    for (int i = 0; i < dataFrame.analogs.size(); i++)
    {
        headingsData += (std::to_string((dataFrame.analogs[i])) + ",");
    }

    // Add a newline character at the end of the data string
    headingsData += "\n";

    // Write the data string to the file
    fout << headingsData;

    // Close the file
    fout.close();
}




// Function to write live data to a text file
void writeLiveTxt(data_frame df, cfg2_frame cfg, int pmuId)
{
    // Open the output file for writing
    std::ofstream fout;
    // Define a string for a line of hashes used for visual separation
    std::string hashLine = "--------------------------------------------------------------------------------------------------------------------------------------------------";

    // Construct the file name using the pmuId
    fout.open("data_" + std::to_string(pmuId) + ".txt");

    // Loop to write data to the file as long as the file stream is open
    while (fout)
    {
        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Write the SOC value
        fout << "SOC" << "->" << std::to_string(df.soc) << std::endl;

        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Write the FRACSEC value
        fout << "FRACSEC" << "->" << std::to_string(df.fracsec) << std::endl;

        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Write the STAT value
        fout << "STAT" << "->" << df.stat << std::endl;

        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Write the FREQUENCY value
        fout << "FREQUENCY" << "->" << std::to_string(df.freq) << std::endl;

        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Write the PHASORS section header
        fout << "PHASORS" << std::endl;

        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Initialize the channel index for phasors
        int chInd = 0;

        // Loop through the phasors and write each one to the file
        for (int i = 0; i < cfg.phnmr; i++)
        {
            fout << cfg.chnam[chInd] << "->" << df.phasors[i].first << "∠" << df.phasors[i].second << std::endl;
            chInd++;
        }

        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Write the ANALOGS section header
        fout << "ANALOGS" << std::endl;

        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Loop through the analogs and write each one to the file
        for (int i = 0; i < cfg.annmr; i++)
        {
            fout << cfg.chnam[chInd] << "->" << df.analogs[i] << std::endl;
            chInd++;
        }

        // Write a line of hashes for visual separation
        fout << hashLine << std::endl;

        // Break the loop after writing the data once
        break;
    }
}



// Function to update a map of data frames with a new data frame
void updateDfMap(data_frame df, std::unordered_map<int, data_frame>& dfMap) {
    // Extract the PMU ID from the data frame
    int pmuId = df.idcode;

    // Update the map with the new data frame, using the PMU ID as the key
    dfMap[pmuId] = df;
}



// Function to create a data frame from received data over a socket
data_frame makeDF(SOCKET clientSocket, cfg2_frame& cfg, std::string fileName, bool& ifCFGAsked, int pmuId, std::mutex& mtx, std::unordered_map<int, data_frame>& dfMap)
{
    // Initialize variables for the number of bytes to delete for different data types
    int delPh = 3, delFr = 3, delAn = 3, delImOrAngle = 3;

    // Adjust the number of bytes to delete based on the format specified in the cfg2_frame
    if (cfg.format[4] == 0)
        delFr = 1;
    if (cfg.format[5] == 0)
        delAn = 1;
    if (cfg.format[6] == 0)
        delPh = 1;
    if (cfg.format[7] == 0)
        delImOrAngle = 1;
    
    int frameSize = 0;
    if (!dfMap.empty()) {
        frameSize = dfMap[cfg.idcode].framesize;
    }
    // Initialize a data_frame object
    data_frame df;

    // Buffer to store received data
    char receive_data_buffer[1024];

    // Receive data from the client socket
    int data_bytes_read = recv(clientSocket, receive_data_buffer, sizeof(receive_data_buffer), 0);
    if (dfMap.empty()) {
        int x = 1;
    }
    else if (data_bytes_read == -1 || data_bytes_read == 0 || data_bytes_read != frameSize)
    {
        // If not, get the error code and return the empty cfg2_frame object
        std::cout << "empty" << std::endl;
        int err = WSAGetLastError();
        return df;
    }
    // Extract and convert various data fields from the received data
    mtx.lock();
    df.framesize = hexToDecimal(hexValue(receive_data_buffer, 2, 3));
    df.idcode = hexToDecimal(hexValue(receive_data_buffer, 4, 5));
    df.soc = hexToDecimal(hexValue(receive_data_buffer, 6, 9));
    df.fracsec = hexToDecimal(hexValue(receive_data_buffer, 10, 13));
    df.stat = hexToBinary(hexValue(receive_data_buffer, 14, 15));
    mtx.unlock();
    // Initialize the current position in the received data buffer
    int cur = 16;

    // Loop to extract and convert phasor data
    for (int i = 0; i < cfg.phnmr; i++)
    {
        mtx.lock();
        std::string str_mag = hexValue(receive_data_buffer, cur, cur + delPh);
        std::string str_ang = hexValue(receive_data_buffer, cur + delPh + 1, cur + (2 * delPh) + 1);
        mtx.unlock();
        cur = cur + 2 * (delPh + 1);
        df.phasors.push_back({binToFloatMag(hexToBinary(str_mag), delPh), binToFloatAngle(hexToBinary(str_ang), delPh)});
    }

    // Extract and convert frequency data
    mtx.lock();
    std::string str_mag = hexValue(receive_data_buffer, cur, cur + delFr);
    mtx.unlock();
    df.freq = binToFloatMag(hexToBinary(str_mag), delFr);
    cur = cur + delPh + 1;

    mtx.lock();
    // Extract and convert the digital frequency data
    str_mag = hexValue(receive_data_buffer, cur, cur + delFr);
    mtx.unlock();

    df.dfreq = binToFloatMag(hexToBinary(str_mag), delFr);
    cur = cur + delPh + 1;

    // Loop to extract and convert analog data
    for (int i = 0; i < cfg.annmr; i++)
    {
        mtx.lock();
        str_mag = hexValue(receive_data_buffer, cur, cur + delAn);
        mtx.unlock();

        cur = cur + delAn + 1;
        df.analogs.push_back(binToFloatMag(hexToBinary(str_mag), delAn));
    }

    // Loop to extract and convert digital data
    for (int i = 0; i < cfg.dgnmr; i++)
    {
        mtx.lock();
        str_mag = hexValue(receive_data_buffer, cur, cur + 1);
        mtx.unlock();
        cur = cur + 2;
        df.digital.push_back(hexToDecimal(str_mag));
    }

    // Check if the frequency is outside the expected range or if the configuration needs to be updated
    if (df.freq < (cfg.fnom - 10) || df.freq > (cfg.fnom + 10))
    {
        sendCFGCmdFrame(clientSocket, pmuId);
        cfg = makeCFG2(clientSocket, pmuId);
        ifCFGAsked = 1;
        return df;
    }
    else if (df.stat[5] == '1' && !ifCFGAsked)
    {
        sendCFGCmdFrame(clientSocket, pmuId);
        cfg = makeCFG2(clientSocket, pmuId);
        ifCFGAsked = 1;
        return df;
    }
    if (df.stat[5] == '0') ifCFGAsked = 0;

    // Write the live data to a text file
    writeLiveTxt(df, cfg, pmuId);

    // Lock the mutex to ensure thread safety when updating the map
    mtx.lock();

    // Update the map with the new data frame
    updateDfMap(df, dfMap);

    // Unlock the mutex
    mtx.unlock();

    // Return the data frame
    return df;
}

