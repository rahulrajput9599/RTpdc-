
// Include necessary libraries for networking and input/output operations

#include <iostream>
#include <winsock2.h>
#include <iomanip>
#include "socketinit.h"

// Function to initialize a socket and establish a connection to a server
SOCKET socketInit(const char *iPAddress, u_short portNum)
{
    // Initialize Winsock library for Windows Sockets API
    WSADATA wsaData;
    
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "Failed to initialize Winsock. Error: " << WSAGetLastError() << std::endl;
        return 1;
    }

    // Create a new socket using the AF_INET address family (IPv4) and SOCK_STREAM protocol (TCP)
    SOCKET clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET)
    {
        std::cerr << "Failed to create socket. Error: " << WSAGetLastError() << std::endl;
        WSACleanup(); // Clean up Winsock resources
        return 1;
    }

    // Prepare the server address structure
    sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;                   // Specify IPv4
    serverAddress.sin_addr.s_addr = inet_addr(iPAddress); // Convert IP address to network byte order
    serverAddress.sin_port = htons(portNum);              // Convert port number to network byte order

    // Attempt to connect to the server using the prepared socket and server address
    if (connect(clientSocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) == SOCKET_ERROR)
    {
        int error = WSAGetLastError();
        std::cerr << "Failed to connect to the server. Error code: " << error << std::endl;
        closesocket(clientSocket); // Close the socket
        WSACleanup();              // Clean up Winsock resources
        return 1;
    }
    // Connection successful, return the connected socket
    return clientSocket;
}
