
#include <winsock2.h>
#include <iomanip>
#include <chrono>
#include "cmdframe.h"
#include "socketinit.h"
#include "structures.h"
#include "utilities.h"
#include <iostream>
#include <cstdio>
#include <string>
#include <fstream>
#include <vector>
#include <map>
#include<unordered_map>
#pragma comment(lib, "ws2_32.lib")
#include<mutex>



// Function to establish a connection to a server
SOCKET connection(std::string ipAddress, int PORT)
{
    // Convert the IP address string to a C-string
    const char *cString = ipAddress.c_str();
    // Initialize the socket connection
    SOCKET clientSocket = socketInit(cString, PORT);

    // Return the socket handle
    return clientSocket;
}

// Function to start data streaming from a PMU (Phasor Measurement Unit)
void startDataStream(SOCKET clientSocket, int pmuId, bool &isClose, std::vector<data_frame> & dfBuffer, std::unordered_map<int, cfg2_frame>& cfgMap, std::mutex &mtx, std::unordered_map<int, data_frame> &dfMap)
{   
    // Flag to check if CFG command has been sent
    bool ifCFGAsked = 0;
    // Send CFG command frame to request configuration data
    sendCFGCmdFrame(clientSocket, pmuId);
    // Make a CFG2 frame by receiving configuration data
    cfg2_frame cfg = makeCFG2(clientSocket, pmuId);

    // Lock the mutex to safely update the configuration map
    mtx.lock();
    cfgMap[pmuId] = cfg;
    mtx.unlock();

    // Send DF command frame to request data frames
    sendDFCmdFrame(clientSocket, pmuId);
    // Write the data frame file header
    std::string fileName = writeDataFrameFileHeader(cfg, pmuId);
   
    // Loop until the data stream is closed
    while (!closeOrNot(isClose, mtx))
    {
        // Make a data frame by receiving data
        data_frame df = makeDF(clientSocket, cfg, fileName, ifCFGAsked, pmuId, mtx, dfMap);
        // Lock the mutex to safely update the data frame buffer
        mtx.lock();
        dfBuffer.push_back(df);
        mtx.unlock();
        
    }
}

// Function to close the data stream
void closeDataStream(std::vector<std::pair<SOCKET,int>> & sockets, bool & isClose, std::mutex &mtx)
{
    int check;
    // Wait for user input to close the data stream
    std::cin >> check;
    if (check == 1) { 
        isClose = 1;
    }
    
    // Wait until the data stream is closed
    while (!closeOrNot(isClose, mtx)) {}
    // Close each socket and clean up
    for (int i = 0; i < sockets.size(); i++) {
        // Send close stream command frame
        sendCloseStreamCmdFrame(sockets[i].first, sockets[i].second);
        // Close the socket
        closesocket(sockets[i].first);
        
        // Clean up the Windows Sockets environment
        WSACleanup();
    }
}


