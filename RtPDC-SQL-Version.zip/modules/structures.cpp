// #include <bits/stdc++.h>
#include<vector>
#include<string>
#include<iostream>
#include "structures.h"
// using namespace std;
