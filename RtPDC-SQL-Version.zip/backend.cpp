#include "./modules/structures.h"
#include "./modules/connection.h"
#include "./modules/socketinit.h"
#include "./modules/utilities.h"
#include <winsock2.h>
#include <iostream>
#include <chrono>
#include <thread>
#include <vector>
#include <map>
#include <unordered_map>
#include <utility>
#include <string>
#include <sstream>
#include <queue>
#include <algorithm>
#include <cmath>
#include <mutex>
#include<set>
#include<mysql.h>
#include "./database.h"




// Function to connect to a PMU (Phasor Measurement Unit) and start data streaming
void connectPMU(std::string ip, int port, int pmuId, bool& isClose, std::vector<data_frame>& dfBuffer, std::mutex& mtx, std::unordered_map<int, data_frame>& dfMap, std::vector<std::pair<SOCKET, int>>& sockets, std::unordered_map<int, cfg2_frame>& cfgMap)
{
    // Initialize a SOCKET variable to hold the client socket
    SOCKET clientSocket;
    // Establish a connection to the PMU using the provided IP and port
    clientSocket = connection(ip, port);
    // Lock the mutex to safely update the sockets vector
    mtx.lock();
    // Add the new socket and its associated PMU ID to the sockets vector
    sockets.push_back({ clientSocket, pmuId });
    mtx.unlock();
    // Check if the socket connection was successful
    if (clientSocket != INVALID_SOCKET) // Note: INVALID_SOCKET is typically used to check for a failed socket creation
    {
        // If the connection is successful, start the data stream for the PMU
        startDataStream(clientSocket, pmuId, isClose, dfBuffer, cfgMap, mtx, dfMap);
    }
}





// Function to sort and process data frames from a queue, either writing to a CSV file or a database
void sortQVector(std::queue<std::vector<data_frame>>& taskQueue, bool& isClose, MYSQL* dbConnection, std::string tableName, bool csvOrDb, std::mutex& mtx, std::unordered_map<int, cfg2_frame>& cfgMap)
{
    // Initialize a vector to hold the current batch of data frames to be processed
    std::vector<data_frame> curVector;
    // Define the name of the output file for CSV data
    std::string fileName = "sortedData.csv";
    // Initialize a variable to track the last processed timestamp
    double lastPush = 0;
    // Loop until the application is signaled to close
    while (!closeOrNot(isClose, mtx))
    {
        // Lock the mutex to safely access the task queue to current task
        mtx.lock();
        // Check if the task queue is not empty
        if (!taskQueue.empty())
        {
            // Pop the front vector of data frames from the queue
            curVector = taskQueue.front();
            // Sort the data frames based on their timestamp
            std::sort(curVector.begin(), curVector.end(), [&cfgMap](const data_frame& df1, const data_frame& df2) {
                // Calculate the timestamp for each data frame
                double time1 = (df1.soc) + (df1.fracsec / ((double)(cfgMap[df1.idcode]).timeBase));
                double time2 = (df2.soc) + (df2.fracsec / ((double)(cfgMap[df2.idcode]).timeBase));
                // Return true if the first timestamp is less than the second
                return time1 < time2;
            });

            // Determine the time base for the current batch of data frames
            double timeBase;
            if (curVector.size() == 0) { timeBase = 1000000.00; } // Default time base if no data frames are present
            else {
                timeBase = cfgMap[curVector[0].idcode].timeBase; // Use the time base of the first data frame
            }
            // Remove data frames from the beginning of the vector until the first data frame's timestamp is not less than the last processed timestamp
            while ((curVector.size() > 0) && (curVector[0].fracsec / timeBase + curVector[0].soc) < lastPush)
            {
                curVector.erase(curVector.begin());
            }
            // Process each remaining data frame in the vector
            for (auto df : curVector)
            {
                // Write the data frame to a csv file if csvOrDb is false, otherwise write to the database
                if (csvOrDb == 0)
                    writeDataframe2File(fileName, df);
                else
                    writeDataframe2Db(dbConnection, df, tableName, cfgMap);
            }
            // Update the last processed timestamp if there are data frames remaining in the vector
            if (curVector.size() > 0)
            {
                lastPush = curVector.back().fracsec / timeBase + curVector.back().soc;
            }
            // Remove the processed vector of data frames from the task queue
            taskQueue.pop();
        }
        // Unlock the mutex after accessing the task queue
        mtx.unlock();
    }
}




// Function to manage the timing of data frame processing and pushing to the task queue
void runTimer(std::queue<std::vector<data_frame>>& taskQueue, std::vector<data_frame>& dfBuffer, bool& isClose, std::mutex& mtx, std::unordered_map<int, cfg2_frame>& cfgMap)
{
    // Initialize variables to track the first and last package arrival times
    int lastPackageArrivalTime = 0;
    int firstPackageArrivalTime = 1000;
    // Lock the mutex to safely access the cfgMap
    mtx.lock();
    // Iterate over the cfgMap to calculate the minimum and maximum package arrival times
    for (auto i : cfgMap)
    {
        // Calculate the package arrival time based on the data rate
        int packageTime = 1000.0 / (i.second.dataRate);
        // Update the lastPackageArrivalTime if the current packageTime is greater
        if (packageTime > lastPackageArrivalTime)
        {
            lastPackageArrivalTime = packageTime;
        }
        // Update the firstPackageArrivalTime if the current packageTime is less
        if (packageTime < firstPackageArrivalTime)
        {
            firstPackageArrivalTime = packageTime;
        }
    }
    // Unlock the mutex after accessing the cfgMap
    mtx.unlock();
    // Calculate the product of the last and first package arrival times, adjusting for rounding
    if (firstPackageArrivalTime == 0 || lastPackageArrivalTime == 0) { return;}
    int product = lastPackageArrivalTime / firstPackageArrivalTime + (lastPackageArrivalTime % firstPackageArrivalTime != 0);
    // Calculate the wait time to balance the processing load
    int waitTime = (product * firstPackageArrivalTime - lastPackageArrivalTime) / 2;
    // Adjust the wait time if the last and first package arrival times are equal
    if (lastPackageArrivalTime == firstPackageArrivalTime)
        waitTime = 10;

    // Loop until the application is signaled to close
    while (!closeOrNot(isClose, mtx))
    {
        // Record the start time for timing
        auto start = std::chrono::steady_clock::now();
        bool firstTime = true;
        // If it's the first iteration, wait for the adjusted time before processing
        if (firstTime)
        {
            // Wait until the adjusted time has passed
            while (std::chrono::steady_clock::now() - start < std::chrono::milliseconds(lastPackageArrivalTime + waitTime))
            {
            }
            // Lock the mutex to safely access the taskQueue and dfBuffer
            mtx.lock();
            // Push the dfBuffer to the taskQueue and clear dfBuffer
            taskQueue.push(dfBuffer);
            dfBuffer.clear();
            // Unlock the mutex after updating the taskQueue and dfBuffer
            mtx.unlock();
            // Set firstTime to false for subsequent iterations
            firstTime = false;
        }
        else
        {
            // Wait until the lastPackageArrivalTime has passed
            while (std::chrono::steady_clock::now() - start < std::chrono::milliseconds(lastPackageArrivalTime))
            {
            }
            // Lock the mutex to safely access the taskQueue and dfBuffer
            mtx.lock();
            // Push the dfBuffer to the taskQueue and clear dfBuffer
            taskQueue.push(dfBuffer);
            dfBuffer.clear();
            // Unlock the mutex after updating the taskQueue and dfBuffer
            mtx.unlock();
        }
    }
}



// Function to manage the backend operations for data processing and storage
void backend(bool& isClose, int numThreads, std::vector<PMU> pmuVector, bool csvOrDb, dbCred dbCred, std::unordered_map<int, data_frame>&dfMap, std::vector<std::pair<SOCKET, int>>& sockets, std::unordered_map<int, cfg2_frame>& cfgMap)
{
    // Initialize a mutex for thread synchronization
    std::mutex mtx;
    // Initialize a vector to buffer data frames before processing
    std::vector<data_frame> dfBuffer;
    // Initialize a queue to manage batches of data frames for processing
    std::queue<std::vector<data_frame>> taskQueue;

    // Initialize a vector of threads for concurrent PMU connections
    std::vector<std::thread> threads;

    // Loop to create threads for connecting to each PMU
    for (int i = 0; i < numThreads; i++)
    {
        // Get the current PMU from the vector
        PMU pmu = pmuVector[i];
        // Launch a thread to connect to the PMU and start data streaming
        threads.emplace_back(connectPMU, pmu.pmuIp, pmu.port, pmu.pmuId, std::ref(isClose), std::ref(dfBuffer), std::ref(mtx), std::ref(dfMap), std::ref(sockets), std::ref(cfgMap));
    }

    // Flag to indicate when all PMUs have sent their configuration data
    bool cfgMade = false;
    // Wait until all PMUs have sent their configuration data
    while (!cfgMade)
    {
        mtx.lock();
        if (cfgMap.size() >= numThreads)
            cfgMade = true;
        mtx.unlock();
    }

    // Initialize the table name for database operations
    std::string tableName;
    // If writing to a database, set up the database connection and table
    if (csvOrDb == 1)
    {
        // Set up the database connection
        MYSQL* dbConnection = DbSetup(dbCred.serverAddress.c_str(), dbCred.userName.c_str(), dbCred.password.c_str(), dbCred.port);
        // Initialize sets to hold the headings for phasors and analogs
        std::set<std::string> headings_phasors;
        std::set<std::string> headings_analogs;
        // Lock the mutex to safely access the cfgMap
        mtx.lock();
        for (auto cur_cfg : cfgMap) {
            int chnam_idx = 0;
            for (; chnam_idx < cur_cfg.second.phnmr; chnam_idx++)
            {
                headings_phasors.insert(cur_cfg.second.chnam[chnam_idx]);
            }
            for (; chnam_idx < cur_cfg.second.phnmr + cur_cfg.second.annmr; chnam_idx++)
            {
                headings_analogs.insert(cur_cfg.second.chnam[chnam_idx]);
            }
        }
        // Unlock the mutex after accessing the cfgMap
        mtx.unlock();
        // Set up the database table with the appropriate headings
        tableName = tableSetup(dbConnection, headings_phasors, headings_analogs);
    }

    // Launch a thread to manage the timing of data frame processing and pushing to the task queue
    std::thread timerThread(runTimer, std::ref(taskQueue), std::ref(dfBuffer), std::ref(isClose), std::ref(mtx), std::ref(cfgMap));
    // Initialize a thread for sorting and processing data frames from the task queue
    std::thread sortingThread;
    // If writing to a database, initialize the sorting thread with the database connection
    if (csvOrDb == 1) {
        MYSQL* dbConnection = DbSetup(dbCred.serverAddress.c_str(), dbCred.userName.c_str(), dbCred.password.c_str(), dbCred.port);
        sortingThread = std::thread(sortQVector, std::ref(taskQueue), std::ref(isClose), dbConnection, tableName, csvOrDb, std::ref(mtx), std::ref(cfgMap)); // Correctly initialize sortingThread
    }
    // If writing to a CSV file, initialize the sorting thread without a database connection
    else {
        sortingThread = std::thread(sortQVector, std::ref(taskQueue), std::ref(isClose), nullptr, tableName, csvOrDb, std::ref(mtx), std::ref(cfgMap)); // Correctly initialize sortingThread
    }
    // Close the data stream for all PMUs
    closeDataStream(sockets, isClose, mtx);
    // Wait for all threads to complete their tasks
    for (auto& thread : threads) {
        thread.join();
    }
    // Wait for the timer thread to complete
    timerThread.join();
    // Wait for the sorting thread to complete
    sortingThread.join();
}


