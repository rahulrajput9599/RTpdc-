#include "./modules/structures.h"
#include <unordered_map>
#include <algorithm>
#include <cctype>
#include <mysql.h>
#include <iostream>
#include<set>
#include <string>
#include <sstream>

MYSQL* DbSetup(const char* DbAddress, const char* UserName, const char* Password, int port)
{
    MYSQL* db, * conn;
    MYSQL_RES* res_set;
    MYSQL_ROW row;

    db = mysql_init(NULL);
    if (!db) return NULL; // Return NULL if db initialization fails

    conn = mysql_real_connect(db, DbAddress, UserName, Password, NULL, port, NULL, 0);
    if (!conn) {
        fprintf(stderr, "Failed to connect to database: Error: %s\n", mysql_error(db));
        mysql_close(conn);
        return NULL; // Return NULL if connection fails
    }

    // SQL query to create a database
    std::string sql = "CREATE DATABASE IF NOT EXISTS RPDC";
    if (mysql_query(conn, sql.c_str())) {
        fprintf(stderr, "Failed to create database: Error: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL; // Return NULL if database creation fails
    }

    // Use the database
    sql = "USE RPDC";
    if (mysql_query(conn, sql.c_str())) {
        fprintf(stderr, "Failed to use database: Error: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL; // Return NULL if database usage fails
    }
    // Return the connection pointer
    return conn;
}


bool isNotAlphaNumOrSpace(char c) {
    //just a function that checks if the provided character is a special character or space or not. To filter in only alphabets.
    return !(std::isalnum(c));
}


std::string deleteSpecialChar(std::string str)
{
    //deletes special character from a given string to validate a sql statement.
    std::string columnName = str;
    std::replace(columnName.begin(), columnName.end(), ' ', '_');
    std::replace_if(columnName.begin(), columnName.end(), isNotAlphaNumOrSpace, '_');
    return columnName;
}

std::string tableNameFunc() {
    // a function that returns table name as a date time string for the current time of creation. i.e. 20240422_0907_data
    std::time_t now = std::time(nullptr);
    std::tm* local_now = std::localtime(&now);
    char buffer[16];
    std::strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M", local_now);
    std::string date_time_str(buffer);
    std::string tableName = date_time_str + "_data";
    return tableName;
}


std::string tableSetup(MYSQL* dbConnection, std::set<std::string> phasorHeadings, std::set<std::string> analogHeadings) {
    // Function to set up a table in a MySQL database based on provided phasor and analog headings

    // Generate a table name using tablename function defined earlier
    std::string tableName = tableNameFunc();

    // Create an output string stream to build the SQL query
    std::ostringstream sql;

    // Begin constructing the CREATE TABLE statement
    sql << "CREATE TABLE IF NOT EXISTS " << tableName << " ("
        << "framesize INT, " // Column for framesize
        << "idcode INT, " // Column for idcode
        << "soc BIGINT, " // Column for soc
        << "fracsec BIGINT, " // Column for fracsec
        << "freq DOUBLE, " // Column for frequency
        << "dfreq DOUBLE, "; // Column for delta frequency

    // Dynamically add columns for phasor measurements
    for (auto phasor_elem : phasorHeadings) {
        // Add columns for magnitude and angle of each phasor measurement
        sql << deleteSpecialChar(phasor_elem) << "_Mag DOUBLE,";
        sql << deleteSpecialChar(phasor_elem) << "_Angle DOUBLE,";
    }

    // Dynamically add columns for analog measurements
    for (auto analog_elem : analogHeadings) {
        // Add columns for each analog measurement, enclosed in backticks to handle reserved words
        sql << "`" << analog_elem << "`" << " DOUBLE,";
    }

    // Remove the trailing comma and space from the SQL query
    std::string query = sql.str();
    query = query.substr(0, query.length() - 1);

    // Complete the CREATE TABLE statement by closing the parentheses
    query += ")";

    // Execute the query against the MySQL database
    if (mysql_query(dbConnection, query.c_str())) {
        // Handle any errors that occur during the execution of the query
        fprintf(stderr, "Failed to create table: Error: %s\n", mysql_error(dbConnection));
        mysql_close(dbConnection);
        return "NULL"; // Return NULL if table creation fails
    }

    // Optionally, print a success message
    // std::cout << "Table created successfully." << std::endl;

    // Return the table name for further uses
    return tableName;
}


// Function to insert a data_frame object into a MySQL database
void writeDataframe2Db(MYSQL* dbConnection, data_frame dataFrame, std::string tableName, std::unordered_map<int, cfg2_frame>& cfgMap) {
    // Construct the SQL query to insert the data_frame into the specified table
    std::ostringstream sql;

    // Start the INSERT INTO statement with the table name and columns
    sql << "INSERT INTO " << tableName << " (framesize, idcode, soc, fracsec, freq, dfreq, ";

    // Dynamically add columns for phasor measurements based on the cfgMap
    int headerIdx = 0;
    for (; headerIdx < cfgMap[dataFrame.idcode].phnmr; headerIdx++)
    {
        // Add columns for magnitude and angle of each phasor measurement
        sql << deleteSpecialChar(cfgMap[dataFrame.idcode].chnam[headerIdx]) << "_Mag,";
        sql << deleteSpecialChar(cfgMap[dataFrame.idcode].chnam[headerIdx]) << "_Angle,";
    }
    // Dynamically add columns for analog measurements
    for (; headerIdx < cfgMap[dataFrame.idcode].annmr + cfgMap[dataFrame.idcode].phnmr; headerIdx++) {
        // Add columns for each analog measurement, enclosed in backticks to handle reserved words
        sql << "`" << cfgMap[dataFrame.idcode].chnam[headerIdx] << "`" << ",";
    }

    // Remove the trailing comma and space from the SQL query
    std::string query1 = sql.str();
    query1 = query1.substr(0, query1.length() - 1);

    // Start the VALUES clause of the INSERT INTO statement
    sql.str(""); // Clear the stringstream
    sql.clear();
    sql << ") VALUES (";

    // Bind values from the data_frame object to the SQL query
    sql << dataFrame.framesize << ",";
    sql << dataFrame.idcode << ",";
    sql << dataFrame.soc << ",";
    sql << dataFrame.fracsec << ",";
    sql << dataFrame.freq << ",";
    sql << dataFrame.dfreq << ",";

    // Bind phasor measurements to the SQL query
    for (int i = 0; i < dataFrame.phasors.size(); i++) {
        sql << dataFrame.phasors[i].first << ",";
        sql << dataFrame.phasors[i].second << ",";
    }
    // Bind analog measurements to the SQL query
    for (int i = 0; i < dataFrame.analogs.size(); i++) {
        sql << dataFrame.analogs[i] << ",";
    }

    // Remove the trailing comma and space from the SQL query
    std::string query2 = sql.str();
    query2 = query2.substr(0, query2.length() - 1);
    std::string query = query1 + query2 + ")";

    // Execute the query to insert the data_frame into the database
    if (mysql_query(dbConnection, query.c_str())) {
        // Handle any errors that occur during the execution of the query
        std::cerr << "Failed to insert data: " << mysql_error(dbConnection) << std::endl;
    }
}
